# =================================================================
# Licensed Materials - Property of IBM
#
# (c) Copyright IBM Corp. 2015 All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# =================================================================

import base64
import json
import time
import webob
from Crypto.Cipher import AES
from oslo_log import log as logging

from keystone.common import dependency
from keystone import exception
from keystone.common import wsgi
from oslo_config import cfg
from keystone.common import provider_api

# configuration constants
SECRET = 'simple_token_secret'
HEADER_KEY = 'simple_token_header'
DEFAULT_HEADER_KEY = 'SimpleToken'
AUTHENTICATION = 'authentication'

# Environment variable used to pass the request context
CONTEXT_ENV = 'openstack.context'

# Environment variable used to pass the request params
PARAMS_ENV = 'openstack.params'

# Message constants
INVALID_TOKEN = "Invalid authentication token"

# API URL constants
V3_API = 'v3'
V2_API = 'v2'

# conf file opt setup and registration
opts = [cfg.StrOpt(HEADER_KEY, default=DEFAULT_HEADER_KEY),
        cfg.StrOpt(SECRET, default=None)]

CONF = cfg.CONF
CONF.register_opts(opts, group=AUTHENTICATION)

LOG = logging.getLogger(__name__)

DEFAULT_DOMAIN_ID = CONF.identity.default_domain_id

PROVIDERS = provider_api.ProviderAPIs

#@dependency.requires('assignment_api', 'identity_api', 'resource_api')

class SimpleTokenAuthentication(wsgi.Middleware):
    """Python paste middleware filter which
    authenticates requests which use simple tokens.

    To configure this middleware:
    (a) Define an 'authentication' section in your
    conf file.

    (b) Specify both the 'simple_token_secret' and
    'simple_token_header' properties in that section.
    The simple_token_secret is the secret key used
    to decrypt the simple token and the simple_token_header
    is the header key which will contain the encrypted
    simple token. For example:

    [authentication]
    simple_token_secret = EzzNhXb17ZsOu9j18Ek7jg==
    simple_token_header = SimpleToken

    (c) In your conf or paste ini, define a filter for
    this class. For example:

    [filter:simpletoken]
    paste.filter_factory = keystone.middleware.simpletoken:
    SimpleTokenAuthentication.factory

    (d) Add the filter to the pipeline you wish to execute it.
    The filter should come after the 'json_body' and 'xml_body'
    filter but before the actual app in the pipeline.

    (e) Make sure this file/class exists in your keystone
    installation under keystone.middleware

    Authentication is request based on a simple token scheme
    used by WebSphere sMash whereupon the simple token
    is a json object encoded (b64) and encrypted (AES)
    in the request header.
    """

    def __init__(self, app, **config):
        # initialization vector
        self._iv = '\0' * 16

        secret = CONF[AUTHENTICATION][SECRET]

        # the secret key is required if this handler is used
        if secret is None:
            raise cfg.RequiredOptError(SECRET)

        self.secret_key = base64.b64decode(secret)
        self.header_key = CONF[AUTHENTICATION][HEADER_KEY]
        super(SimpleTokenAuthentication, self).__init__(app)

    def _get_charset(self, request):
        for item in request.headers.get('Content-Type').split(';'):
            if item.find('charset=') != -1:
                return item.strip().replace('charset=', '')
        return 'UTF-8'

    def _unpad(self, string):
        # remove padding from decrypted string
        return string[0:-ord(string[-1])]

    def _get_token(self, request):
        if request:
            return request.headers.get(self.header_key)
        return None

    def _validate_simple_token(self, json_token, username=None, user_ref=None,
                                domain_id=None, identity_api_version=V2_API):

        # validate well formed token properties
        if json_token['username'] is None or json_token['expiration'] is None:
            raise AssertionError('Malformed simple token, the information of'
                                 ' user should be included in the simple'
                                 ' token.')

        if identity_api_version == V2_API:
            domain_id = DEFAULT_DOMAIN_ID
        elif identity_api_version == V3_API:
            json_domain_id = None
            if json_token.get('domainId', None) is None and json_token.get(
                                                  'domainName', None) is None:
                raise AssertionError('Malformed simple token, the information'
                                     ' of domain should be included in the'
                                     ' simple token.')
            if json_token.get('domainId', None) is None:
                try:
                    domain_ref = PROVIDERS.resource_api.get_domain_by_name(
                                                     json_token['domainName'])
                    json_domain_id = domain_ref['id']
                except exception.DomainNotFound:
                    raise AssertionError('Invalid domain name in simple token')
            else:
                json_domain_id = json_token['domainId']
            if not user_ref and domain_id != json_domain_id:
                raise AssertionError('The domain in request body does not'
                                     ' match the domain in simple token')
        if user_ref is None:
            try:
                user_ref = PROVIDERS.identity_api.get_user_by_name(
                                                     username, domain_id)
            except exception.UserNotFound:
                raise AssertionError('Invalid user')

        # verify token username matches username in body
        if json_token['username'] != user_ref['name']:
            raise AssertionError('Invalid username in simple token')

        # ensure token has not expired
        if int(json_token['expiration']) < int(round(time.time() * 1000)):
            raise AssertionError('Simple token is expired')

    def process_request(self, request):

        if request.environ.get('REMOTE_USER', None) is not None:
            # authenticated upstream
            return self.application
        if (request.environ.get('PATH_INFO', None) != '/tokens' and
            request.environ.get('PATH_INFO', None) != '/auth/tokens'):
            # only authenticate for tokens request
            return self.application

        script_name = request.environ.get('SCRIPT_NAME', None)
        if script_name is None:
            return self.application

        if script_name.find(V3_API) >= 0:
            self.process_v3_request(request)
        elif script_name.find(V2_API) >= 0:
            self.process_v2_request(request)
        else:
            return self.application

    def process_v2_request(self, request):

        params = request.environ.get(PARAMS_ENV, None)

        auth = None

        # only try simple token authn when passwordCredentials is set
        if params is not None:
            auth = params.get('auth', None)

        if auth and auth.get('passwordCredentials', None) is not None:
            username = auth['passwordCredentials'].get('username', None)

            try:
                user_ref = None

                if username is None:
                    user_id = auth['passwordCredentials'].get('userId', None)
                    try:
                        user_ref = PROVIDERS.identity_api.get_user(user_id)
                        username = user_ref['name']
                    except exception.UserNotFound:
                        raise AssertionError('Invalid user id')

                if self.authenticate(request, username, user_ref):
                    context = request.environ.get(CONTEXT_ENV, {})
                    # indicate remote authentication via context
                    context['REMOTE_USER'] = username
                    request.environ[CONTEXT_ENV] = context
                    request.environ['REMOTE_USER'] = username
            except Exception, e:
                LOG.debug("Simple token authentication failed due to: " +
                          str(e))
                return wsgi.render_exception(
                            exception.Unauthorized(INVALID_TOKEN))

    def process_v3_request(self, request):

        params = request.environ.get(PARAMS_ENV, None)
        auth = None

        # only try simple token authn when identity is set for v3 api
        if params is not None:
            auth = params.get('auth', None)

        if auth and auth.get('identity', None) is not None:
            identity_pwd = auth['identity'].get('password', None)
            identity_methods = auth['identity'].get('methods', None)
            if self._get_token(request) is not None and identity_methods is \
                             not None and len(identity_methods):
                del identity_methods[:]
            user_ref = None
            domain_id = None
            if identity_pwd and identity_pwd.get('user', None) is not None:
                username, user_ref = self._get_user_from_v3_request(
                                                        identity_pwd['user'])
                if identity_pwd['user'] and identity_pwd['user'].get('domain',
                                                             None) is not None:
                    domain_id = self._get_domain_from_v3_request(
                                    identity_pwd['user'].get('domain', None))
            if user_ref or domain_id:
                try:
                    if self.authenticate(request, username, user_ref,
                                          domain_id, V3_API):
                        context = request.environ.get(CONTEXT_ENV, {})
                        # indicate remote authentication via context
                        if not domain_id:
                            domain_id = DEFAULT_DOMAIN_ID
                        domain_ref = PROVIDERS.resource_api.get_domain(domain_id)
                        context['REMOTE_USER'] = username
                        request.environ[CONTEXT_ENV] = context
                        request.environ['REMOTE_USER'] = username
                        request.environ['REMOTE_DOMAIN'] = domain_ref.get('name')
                except Exception, e:
                    LOG.debug("Simple token authentication failed due to: " +
                              str(e))
                    return wsgi.render_exception(
                                 exception.Unauthorized(INVALID_TOKEN))

    def _get_user_from_v3_request(self, user):
        username = user.get('name', None)
        user_ref = None
        if username is None:
            user_id = user.get('id', None)
            try:
                user_ref = PROVIDERS.identity_api.get_user(user_id)

                username = user_ref['name']
            except exception.UserNotFound:
                raise AssertionError('Invalid user id')
        return username, user_ref

    def _get_domain_from_v3_request(self, domain):
        domain_id = domain.get('id', None)
        domain_name = domain.get('name', None)
        if not domain_id and domain_name:
            try:
                domain_ref = PROVIDERS.resource_api.get_domain_by_name(domain_name)

                domain_id = domain_ref['id']
            except exception.DomainNotFound:
                raise AssertionError('Invalid domain name in request body')
        return domain_id

    def authenticate(self, request=None, username=None, user_ref=None,
                      domain_id=None, api_version=V2_API):
        """Authenticate the request if applicable using simple token"""

        simple_token = self._get_token(request)

        if simple_token is not None:
            LOG.debug("Authenticating simple token")

            decoded_token = base64.b64decode(simple_token)
            decryptor = AES.new(self.secret_key, AES.MODE_CBC, self._iv)

            try:
                charset = self._get_charset(request)
                json_token = json.loads(self._unpad(
                    decryptor.decrypt(decoded_token).decode(charset)))
            except:
                # invalid json, token may have been tampered
                raise AssertionError('Malformed simple token')

            self._validate_simple_token(json_token, username, user_ref,
                                         domain_id, api_version)
            return True

        # no simple token in request, handler not applicable
        return False
